// Package memqueue provides an in-memory queue.Queue implementation for
// use with the publisher pipeline.
// The queue implementation is registered as queue type "mem".
package memqueue
