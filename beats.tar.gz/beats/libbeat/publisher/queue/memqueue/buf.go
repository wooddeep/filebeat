package memqueue
