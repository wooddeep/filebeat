// Package queuetest provides common functionality tests all queue implementations
// must pass. These tests guarantee a queue fits well into the publisher pipeline.
package queuetest
