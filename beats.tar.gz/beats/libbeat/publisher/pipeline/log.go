package pipeline

import "github.com/elastic/beats/libbeat/logp"

var defaultLogger = logp.NewLogger("publish")
