package mysql

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"time"

	_ "github.com/go-sql-driver/mysql"

	"github.com/elastic/beats/libbeat/beat"
	"github.com/elastic/beats/libbeat/common"
	"github.com/elastic/beats/libbeat/common/file"
	"github.com/elastic/beats/libbeat/logp"
	"github.com/elastic/beats/libbeat/outputs"
	"github.com/elastic/beats/libbeat/outputs/codec"
	"github.com/elastic/beats/libbeat/publisher"
)

func init() {
	outputs.RegisterType("mysql", makeMysqlout)
}

type mysqlOutput struct {
	beat     beat.Info
	observer outputs.Observer
	db       *sql.DB
	rotator  *file.Rotator
	codec    codec.Codec
	cfg      config
}

// makeFileout instantiates a new file output instance.
func makeMysqlout(beat beat.Info, observer outputs.Observer, cfg *common.Config) (outputs.Group, error) {
	config := defaultConfig
	if err := cfg.Unpack(&config); err != nil {
		return outputs.Fail(err)
	}

	// disable bulk support in publisher pipeline
	cfg.SetInt("bulk_max_size", -1, -1)

	mo := &mysqlOutput{
		beat:     beat,
		observer: observer,
	}

	if err := mo.init(beat, config); err != nil {
		return outputs.Fail(err)
	}

	return outputs.Success(-1, 0, mo)
}

func (out *mysqlOutput) init(beat beat.Info, c config) error {
	var path string
	if c.Filename != "" {
		path = filepath.Join(c.Path, c.Filename)
	} else {
		path = filepath.Join(c.Path, out.beat.Beat)
	}
	out.cfg = c
	dsn := fmt.Sprintf("%s:%s@%s(%s)/%s", c.Username, c.Password, "tcp", c.Address, c.Database)
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		fmt.Printf("Open mysql failed,err:%v\n", err)
		return err
	}
	db.SetConnMaxLifetime(100 * time.Second) //最大连接周期，超过时间的连接就close
	db.SetMaxOpenConns(100)                  // 设置最大连接数
	db.SetMaxIdleConns(16)                   //设置闲置连接数
	out.db = db                              // 创建mysql连接

	out.rotator, err = file.NewFileRotator(
		path,
		file.MaxSizeBytes(c.RotateEveryKb*1024),
		file.MaxBackups(c.NumberOfFiles),
		file.Permissions(os.FileMode(c.Permissions)),
	)
	if err != nil {
		return err
	}

	out.codec, err = codec.CreateEncoder(beat, c.Codec)
	if err != nil {
		return err
	}

	logp.Info("Initialized file output. "+
		"path=%v max_size_bytes=%v max_backups=%v permissions=%v",
		path, c.RotateEveryKb*1024, c.NumberOfFiles, os.FileMode(c.Permissions))

	return nil
}

// Implement Outputer
func (out *mysqlOutput) Close() error {
	return out.rotator.Close()
}

func insertData(log string, db *sql.DB) {
	result, err := db.Exec("insert INTO mgsgwlog(info) values(?)", log)
	if err != nil {
		logp.Info("Insert failed,err:%v", err)
		return
	}
	lastInsertID, err := result.LastInsertId() //插入数据的主键id
	if err != nil {
		logp.Info("Get lastInsertID failed,err:%v", err)
		return
	}
	logp.Info("LastInsertID: %d", lastInsertID)
	rowsaffected, err := result.RowsAffected() //影响行数
	if err != nil {
		logp.Info("Get RowsAffected failed,err:%v", err)
		return
	}
	logp.Info("RowsAffected: %d", rowsaffected)
}

func (out *mysqlOutput) Publish(batch publisher.Batch) error {
	defer batch.ACK()

	st := out.observer
	events := batch.Events()
	st.NewBatch(len(events))

	logp.Err("Initialized file output. #### %s", out.cfg.Address)

	dropped := 0
	for i := range events {
		event := &events[i]
		serializedEvent, err := out.codec.Encode(out.beat.Beat, &event.Content)
		if err != nil {
			if event.Guaranteed() {
				logp.Critical("Failed to serialize the event: %v   ", err)
			} else {
				logp.Warn("Failed to serialize the event: %v--", err)
			}

			dropped++
			continue
		}

		// TODO 写入到mysql
		//_, err = out.rotator.Write(append(serializedEvent, '\n'))
		insertData(string(serializedEvent), out.db)
		logp.Info("%v", string(serializedEvent))
		if err != nil {
			st.WriteError(err)
			if event.Guaranteed() {
				logp.Critical("Writing event to file failed with: %v", err)
			} else {
				logp.Warn("Writing event to file failed with: %v", err)
			}
			dropped++
			continue
		}

		st.WriteBytes(len(serializedEvent) + 1)

	}

	st.Dropped(dropped)
	st.Acked(len(events) - dropped)

	return nil
}
