package version

const defaultBeatVersion = "6.2.4"
