//+build !linux !go1.8 !cgo

package plugin

func Initialize() error {
	return nil
}
