package common

// standardized status values
const (
	OK_STATUS           = "OK"
	ERROR_STATUS        = "Error"
	SERVER_ERROR_STATUS = "Server Error"
	CLIENT_ERROR_STATUS = "Client Error"
)
